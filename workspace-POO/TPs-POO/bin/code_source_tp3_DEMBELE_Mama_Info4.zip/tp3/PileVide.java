package tp3;

/**
 * Classe définissant l'exception levée quand on a une
 * pile vide.
 * @author Mama
 *
 */
public class PileVide extends ExceptionForte{
	
	public PileVide() {
		super();
	}
}
