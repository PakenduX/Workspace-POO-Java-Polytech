package tp3;

/**
 * Classe définissant l'exception levée quand l'élément
 * n'appartient pas à la liste.
 * @author Mama
 *
 */
public class NotElementListe extends ExceptionFaible {

	public NotElementListe() {
		super();
	}
}
