package tp3;

/**
 * Classe définissant la classe des exceptions fortes
 * @author Mama
 *
 */
public class ExceptionForte extends Exception{
	
	public ExceptionForte() {
		System.out.println("Il y a une exception forte");
	}

}
