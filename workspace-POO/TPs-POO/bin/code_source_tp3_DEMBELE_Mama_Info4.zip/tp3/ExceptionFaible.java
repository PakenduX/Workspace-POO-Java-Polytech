package tp3;

/**
 * Classe définissant la classe des exceptions faibles
 * @author Mama
 *
 */
public class ExceptionFaible extends Exception{

		public ExceptionFaible() {
			System.out.println("Il y a une exception faible");
		}
}
