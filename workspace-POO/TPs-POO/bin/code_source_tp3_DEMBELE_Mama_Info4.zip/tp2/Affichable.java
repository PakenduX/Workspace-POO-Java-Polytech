package tp2;

/**
 * Interface qui permet de définir l'ensemble
 * des classes affichables.
 * @author Mama
 *
 */
public interface Affichable {
	
	public void afficher();
	
	public default void afficherLight() {
		System.out.println("Je ne sais pas afficherLight");
	}

}
