package tp2;

/**
 * L'interface définissant l'ensemble des 
 * éléments compactables.
 * @author papa
 *
 */
public interface Compactable {
	
	public void compacter(int nb_compactable);
	
	public default void dilater() {
		System.out.println("Je ne sais pas dilater");
	}
}
