package tp6;

public interface BidirIterator extends MonIterator{
	
	public int precedent();
}
