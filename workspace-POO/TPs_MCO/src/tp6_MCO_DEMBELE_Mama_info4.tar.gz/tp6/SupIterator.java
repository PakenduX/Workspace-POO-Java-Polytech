package tp6;

public interface SupIterator extends MonIterator{
	
	public void supprimer();
}