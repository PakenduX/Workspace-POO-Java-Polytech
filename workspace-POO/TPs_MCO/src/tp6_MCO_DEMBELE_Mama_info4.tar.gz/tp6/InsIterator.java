package tp6;

public interface InsIterator extends MonIterator{
	
	public void insere(int i);
}