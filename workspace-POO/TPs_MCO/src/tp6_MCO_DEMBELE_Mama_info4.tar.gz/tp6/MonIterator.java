package tp6;

public interface MonIterator {
	
	public int courant();
	public int suivant();
	public boolean fin();
	
}
