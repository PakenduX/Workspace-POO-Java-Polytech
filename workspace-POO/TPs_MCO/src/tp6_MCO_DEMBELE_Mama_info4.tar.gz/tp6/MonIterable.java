package tp6;

public interface MonIterable {
	
	public MonIterator createIterator();

}
