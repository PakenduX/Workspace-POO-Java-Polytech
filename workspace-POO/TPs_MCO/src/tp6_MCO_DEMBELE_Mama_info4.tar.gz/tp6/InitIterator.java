package tp6;

public interface InitIterator extends MonIterator{
	
	public void init();
}
