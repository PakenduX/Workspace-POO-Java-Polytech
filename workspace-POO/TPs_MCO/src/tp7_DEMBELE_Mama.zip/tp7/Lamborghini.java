package tp7;

public class Lamborghini implements Voiture {

    static double prix = 300000.0 ;

    public double getPrix_ajoute() {
        return prix;
    }

    public double getPrix(){
        return prix;
    }

    public String toString(){
        return "La lambo" ;
    }

}