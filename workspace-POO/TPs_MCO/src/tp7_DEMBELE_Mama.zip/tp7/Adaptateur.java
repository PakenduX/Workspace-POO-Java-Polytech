package tp7;

public interface Adaptateur<E>{
	
	public void push(E e);
	
	public E peek();
	
	public E pop();

}
