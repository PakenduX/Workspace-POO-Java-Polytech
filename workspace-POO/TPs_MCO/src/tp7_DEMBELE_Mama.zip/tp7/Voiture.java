package tp7;

public interface Voiture {

    public double getPrix();
    public String toString();

}