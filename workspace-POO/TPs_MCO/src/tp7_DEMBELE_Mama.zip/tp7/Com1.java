package tp7;

public class Com1 implements Command{

	public void execute(String s) {
		System.out.println(s);
		
	}
	
}
