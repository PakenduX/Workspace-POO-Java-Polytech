package tp7;

public interface Command {
	
	public void execute(String s);

}
