package tp7;

public class GPS extends DecorateurInterieur {

    public GPS(Voiture v) {
        super(v, "GPS", 5000);
    }
}