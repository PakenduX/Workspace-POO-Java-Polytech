package tp7;

public class Ferrari implements Voiture {

    static double prix = 200000.0 ;

    public double getPrix_ajoute() {
        return prix;
    }

    public double getPrix() {
        return prix;
    }

    public String toString(){
        return "La Ferrari" ;
    }

}