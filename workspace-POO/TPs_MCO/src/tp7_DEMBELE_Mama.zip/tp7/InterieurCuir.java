package tp7;

public class InterieurCuir extends DecorateurInterieur {

    public InterieurCuir(Voiture v) {
        super(v, "Intérieur cuir", 3000);
    }

}
