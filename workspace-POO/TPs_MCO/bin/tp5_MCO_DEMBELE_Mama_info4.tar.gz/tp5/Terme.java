package tp5;

public abstract class Terme extends Expression{

	public abstract double evaluer();
	
}
