package tp5;

public abstract class Facteur extends Terme{

	public abstract double evaluer();

}
