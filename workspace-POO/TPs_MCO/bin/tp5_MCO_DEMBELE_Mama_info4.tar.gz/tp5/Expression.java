package tp5;

public abstract class Expression {

	public abstract double evaluer();
}
