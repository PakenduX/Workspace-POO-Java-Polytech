package tp1;

import javax.swing.*;

/**
 * 1. Création de fenêtres
 * @author DEMBELE Mama
 */
public class MaFenetre extends JFrame {

    private MonPanneau p;

    public MaFenetre(String title, int x, int y, int larg, int haut){
        setTitle(title);
        setBounds(x, y, larg, haut);
        p = new MonPanneau();
        add(p);

    }
}
