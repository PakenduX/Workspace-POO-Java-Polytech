package tp2;

import javax.swing.*;

public class Main {

    public static void main(String[] args){

        /*
         * 1. Clic sur un bouton
         */
        MyFrame f = new MyFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);

        /*
         * 2. Fermeture d'une fenêtre
         */

          FermetureFenetre ff = new FermetureFenetre();
          ff.setVisible(true);

        /*
         * 3. Mouvement de souris
         */

        MouvementSouris ms = new MouvementSouris();
        ms.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ms.setVisible(true);

        /*
         * 4. Dessin avec le clavier
         */

        DessinAvecClavierFrame dacf = new DessinAvecClavierFrame();
        dacf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dacf.setVisible(true);

        /*
         * 5. Clic et déplacement avec la souris
         */

        ClicDeplacementSourisFrame cdsf = new ClicDeplacementSourisFrame();
        cdsf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cdsf.setVisible(true);

    }
}
