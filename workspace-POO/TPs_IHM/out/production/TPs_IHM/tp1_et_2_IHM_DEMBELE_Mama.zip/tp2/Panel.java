package tp2;

import javax.swing.*;

public class Panel extends JPanel {

}
